{define}
{define}

{body}

{LinearLayout;
    layout_width="fill";
    gravity="center|top";
    orientation="horizontal";
    layout_height="fill";
    {CardView;
        layout_width=0.94*wh;
        layout_marginLeft="2";
        layout_marginTop=0.072*wh;
        layout_height=0.68*hh;
        radius="3dp";
        {LinearLayout;
            orientation="vertical";
            layout_width="-1";
            layout_height="-1";

            --{ui},1

        };
    };
};

<alittlemc/split>

{LinearLayout;
    layout_width="-1";
    layout_height="-1";

    --{bar},2

};

<alittlemc/split>
--{list_ui},3
<alittlemc/split>
--{list_fun},4
<alittlemc/split>
--{top},5
<alittlemc/split>
--{prog(ss)},6
<alittlemc/split>
--{bottom},7
<alittlemc/split>
--{end},8
<alittlemc/split>
--{xfun(i)},9
<alittlemc/split>
--{load_build},10
<alittlemc/split>
--{load_main},11
<alittlemc/split>
--{pagev},12
<alittlemc/split>
--{drawer},13
{body}