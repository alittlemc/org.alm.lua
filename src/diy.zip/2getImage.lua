{define}
{define}

{body}
--{ui},1
{LinearLayout;
      layout_width="fill";
      gravity="center|top";
      orientation="horizontal";
      layout_height="fill";
      {CardView;
        layout_width=0.94*wh;
        layout_marginLeft="2";
        layout_marginTop=0.06*wh;
        layout_height=0.68*hh;
        radius="3dp";
        
        {LinearLayout;
          orientation="vertical";
          layout_width="-1";
          layout_height="-1";
          gravity="center";
          {ImageView;
          layout_width="-1";
          layout_height="-1";
          id="getImage@id@";
          };
        };
    };
};
<alittlemc/split>
--{bar},2
{LinearLayout;
orientation="vertical";
    layout_width="-1";
    layout_height="-1";
    gravity="center|top";
    {TextView;
    id="textrbg@id@";
    
    };
        {TextView;
    id="new@id@";
    
    };
};
<alittlemc/split>
--{list_ui},3
<alittlemc/split>
--{list_fun},4
<alittlemc/split>
--{top},5
<alittlemc/split>
--{prog(ss)},6
<alittlemc/split>
--{bottom},7
<alittlemc/split>
--{end},8
<alittlemc/split>
--{xfun(i)},9
if i==@id@ then

end
<alittlemc/split>
--{load_build},10
<alittlemc/split>
--{load_main},11
import "android.graphics.BitmapFactory"
import "android.graphics.Color"
src=BitmapFactory.decodeFile(activity.getLuaDir().."/icon.png")
--src=BitmapFactory.decodeFile(mulu.."alittlemc.jpg")
--更多方法查看 java浏览器 的 BitmapFactory
print(src)
function ARGB(textid,src,x,y)
  pixelColor = src.getPixel(x,y);
  A = Color.alpha(pixelColor);
  R = Color.red(pixelColor);
  G = Color.green(pixelColor);
  B = Color.blue(pixelColor);
  textid.setTextColor(Color.argb(A,R,G,B))
  .setText("A:"..A.." R:"..R.." G:"..G.." B:"..B)
end

getImage@id@.setImageBitmap(src)
h=src.getHeight();
w= src.getWidth();
getImage@id@.setLayoutParams(LinearLayout.LayoutParams(w,h))

getImage@id@.onTouch=function(v,e)
  x=e.getX()
  y=e.getY()
  new@id@.Text="x="..x.."\ny="..y
  ARGB(textrbg@id@,src,x,y)
  end
<alittlemc/split>
--{pagev},12
<alittlemc/split>
--{drawer},13
{body}